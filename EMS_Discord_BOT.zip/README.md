# EMS_Discord_BOT
 A bot to help take care of ems workers service
